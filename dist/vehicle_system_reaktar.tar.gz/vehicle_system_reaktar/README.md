# vehicle_system_reaktar - Reaktar Actor Framework

Code-generated AUTOSAR Adaptive Actor and Test Bench framework for:
`vehicle_system.arxml`

## Directory Structure
- `include/reaktar/`: Standard Reaktar core headers (traits, static dispatcher, tag definitions).
- `include/reaktar.hpp`: Master umbrella header.
- `include/generated_framework/`: Code-generated Actor and TestBench headers for all Adaptive Applications.
- `CMakeLists.txt`: CMake package providing the `vehicle_system_reaktar` INTERFACE library target.

## Usage in CMake
Add this package to your project:
```cmake
add_subdirectory(path/to/vehicle_system_reaktar)
target_link_libraries(your_application PRIVATE vehicle_system_reaktar)
```
